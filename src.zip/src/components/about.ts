import { motion } from 'framer-motion';
import { Code2, Database, Zap, Palette } from 'lucide-react';
import { personalInfo } from '../data/portfolioData';

const About = () => {
  const skills = [
    { icon: Code2, label: 'React / Next.js' },
    { icon: Database, label: 'Node.js / Prisma' },
    { icon: Zap, label: 'TypeScript' },
    { icon: Palette, label: 'Tailwind CSS' },
  ];

  return (
    <section id="apropos" className="py-20 bg-white/5">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              À propos
            </span>
          </h2>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <p className="text-gray-300 leading-relaxed text-lg">
                {personalInfo.description}
              </p>
              <div className="mt-6 space-y-2 text-gray-400">
                <p>📍 {personalInfo.location}</p>
                <p>📧 {personalInfo.email}</p>
                <p>📱 {personalInfo.phone}</p>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4">Compétences</h3>
              <div className="grid grid-cols-2 gap-4">
                {skills.map((skill, index) => (
                  <motion.div
                    key={skill.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="bg-white/5 rounded-xl p-4 text-center hover:bg-white/10 transition-colors border border-white/5"
                  >
                    <skill.icon className="w-8 h-8 text-primary mx-auto mb-2" />
                    <span className="text-sm">{skill.label}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;