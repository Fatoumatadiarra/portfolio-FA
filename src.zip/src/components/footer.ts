import { personalInfo } from '../data/portfolioData';

const Footer = () => {
  return (
    <footer className="py-6 border-t border-white/10 text-center text-gray-400 text-sm">
      <div className="container mx-auto px-6">
        <p>
          © {new Date().getFullYear()} {personalInfo.name}. Fait avec ❤️ et React
        </p>
      </div>
    </footer>
  );
};

export default Footer;